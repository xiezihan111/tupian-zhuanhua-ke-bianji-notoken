"""Portable image reconstruction: native PPTX shapes/text + cropped source artwork.
No API key or model calls. Per-image configs live in config/.
"""
from pathlib import Path
import json, math, zipfile, posixpath, shutil, argparse
import numpy as np
from PIL import Image
import cv2
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.oxml.xmlchemy import OxmlElement
from lxml import etree as ET
ROOT=Path(__file__).resolve().parent
EMU=9525
WIDTH,HEIGHT=1239,676
NSR='http://schemas.openxmlformats.org/package/2006/relationships'; NSP='http://schemas.openxmlformats.org/presentationml/2006/main'; NSD='http://schemas.openxmlformats.org/officeDocument/2006/relationships'; NSC='http://schemas.openxmlformats.org/package/2006/content-types'
def rgb(v):return RGBColor.from_string(v.lstrip('#'))
def style(shape,fill=None,stroke=None,width=1):
 if hasattr(shape,'fill'):
  if fill:shape.fill.solid();shape.fill.fore_color.rgb=rgb(fill)
  else:shape.fill.background()
 if stroke:shape.line.color.rgb=rgb(stroke);shape.line.width=Pt(width*.75)
 else:shape.line.fill.background()
def xybox(b,z,ox,oy):
 x,y,w,h=b;return [int((x*z+ox)*EMU),int((y*z+oy)*EMU),int(w*z*EMU),int(h*z*EMU)]
def pathshape(sl,pts,z,ox,oy,fill,stroke,width,closed=True,arrow=False):
 pts=[((x*z+ox)*EMU,(y*z+oy)*EMU) for x,y in pts]
 if not closed:
  for a,b in zip(pts,pts[1:]):
   sp=sl.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,int(a[0]),int(a[1]),int(b[0]),int(b[1]));style(sp,None,stroke,width*z)
 else:
  fb=sl.shapes.build_freeform(pts[0][0],pts[0][1],scale=1);fb.add_line_segments(pts[1:],close=True);sp=fb.convert_to_shape();style(sp,fill,stroke,width*z)
 if arrow:
  # Explicit editable triangle: portable rendering does not depend on path arrowhead support.
  x1,y1=pts[-2];x2,y2=pts[-1];dx=x2-x1;dy=y2-y1;length=math.hypot(dx,dy)
  if length:
   ux,uy=dx/length,dy/length;head=max(8,min(22,width*2.3))*z*EMU;half=head*.48
   triangle=[(x2,y2),(x2-ux*head-uy*half,y2-uy*head+ux*half),(x2-ux*head+uy*half,y2-uy*head-ux*half)]
   ff=sl.shapes.build_freeform(*triangle[0],scale=1);ff.add_line_segments(triangle[1:],close=True);tip=ff.convert_to_shape();style(tip,stroke,None,0);tip.name='可编辑箭头端点'

 return sp

def prepare_assets(c,out):
 im=Image.open(ROOT/c['image']).convert('RGB');a=np.array(im);mask=np.zeros(a.shape[:2],np.uint8)
 for region in c.get('erase_regions',[{'box':b} for b in c['erase_boxes']]):
  x,y,w,h=region['box'];x0,y0=max(0,int(x)-1),max(0,int(y)-1);x1,y1=min(a.shape[1],math.ceil(x+w)+1),min(a.shape[0],math.ceil(y+h)+1)
  area=a[y0:y1,x0:x1];gray=cv2.cvtColor(area,cv2.COLOR_RGB2GRAY);bg=float(np.median(gray));color=region.get('color')
  light=(color is not None and sum(int(color.lstrip('#')[j:j+2],16) for j in (0,2,4))>560) if color else bg<145
  glyph=(gray>max(155,bg+30)) if light else (gray<min(145,bg-30))
  glyph=cv2.dilate(glyph.astype('uint8'),np.ones((3,3),np.uint8))*255
  mask[y0:y1,x0:x1]=np.maximum(mask[y0:y1,x0:x1],glyph)
 # Only lettering is removed from the source; layout graphics are authored separately.
 clean=cv2.inpaint(a,mask,3,cv2.INPAINT_TELEA)
 assets=[]
 for j,d in enumerate(c['images']):
  x,y,w,h=map(int,d['box']);piece=clean[y:y+h,x:x+w].copy();alpha=np.full(piece.shape[:2],255,np.uint8)
  if d.get('polygon'):
   alpha[:]=0;cv2.fillPoly(alpha,[np.array(d['polygon'],np.int32)-[x,y]],255)
  if c['background']=='#FFFFFF' and '现场' not in d['name'] and '屏幕' not in d['name'] and '画面' not in d['name']:
   # Preserve enclosed white highlights; remove only white exterior connected to border.
   light=np.min(piece,axis=2)>241
   from scipy.ndimage import binary_propagation
   seeds=np.zeros_like(light);seeds[0,:]=light[0,:];seeds[-1,:]=light[-1,:];seeds[:,0]=light[:,0];seeds[:,-1]=light[:,-1]
   exterior=binary_propagation(seeds,mask=light);alpha[exterior]=0
  f=out/f'asset_{j+1:02}.png';Image.fromarray(np.dstack([piece,alpha])).save(f);assets.append((d,f))
 return a,assets

def build(configs=None,output='output/editable.pptx'):
 files=configs or sorted((ROOT/'config').glob('page_*.json'));prs=Presentation();prs.slide_width=WIDTH*EMU;prs.slide_height=HEIGHT*EMU;reports=[]
 for f in files:
  c=json.loads(Path(f).read_text());idx=int(Path(f).stem.split('_')[-1]);out=ROOT/'output'/f'page_{idx:02}';out.mkdir(parents=True,exist_ok=True);orig,assets=prepare_assets(c,out)
  w,h=c['size'];z=min(WIDTH/w,HEIGHT/h);ox=(WIDTH-w*z)/2;oy=(HEIGHT-h*z)/2
  sl=prs.slides.add_slide(prs.slide_layouts[6]);sl.background.fill.solid();sl.background.fill.fore_color.rgb=rgb(c['background'])
  def add(s):
   kind=s['kind']
   if kind in ('path','poly'):sp=pathshape(sl,s['points'],z,ox,oy,s.get('fill'),s.get('stroke'),s.get('width',1),closed=kind=='poly',arrow=s.get('arrow',False))
   else:
    typ={'rect':MSO_SHAPE.RECTANGLE,'roundRect':MSO_SHAPE.ROUNDED_RECTANGLE,'ellipse':MSO_SHAPE.OVAL,'upArrow':MSO_SHAPE.UP_ARROW,'downArrow':MSO_SHAPE.DOWN_ARROW,'rightArrow':MSO_SHAPE.RIGHT_ARROW}[kind]
    sp=sl.shapes.add_shape(typ,*xybox(s['box'],z,ox,oy));style(sp,s.get('fill'),s.get('stroke'),s.get('width',1)*z)
    if kind=='roundRect':sp.adjustments[0]=.07
   sp.name=s.get('name',f'可编辑_{kind}_{len(sl.shapes)}')
  for s in sorted([x for x in c['shapes'] if not x.get('front')],key=lambda x:not x.get('back')):add(s)
  for d,img in assets:
   sp=sl.shapes.add_picture(str(img),*xybox(d['box'],z,ox,oy));sp.name=d['name']
  for s in c['shapes']:
   if s.get('front'):add(s)
  count=0
  for t in c['texts']:
   if t.get('omit'):continue
   x,y,w,h=t['box'];string=t['text'];color=t.get('color')
   if not color:
    area=orig[max(0,int(y)):min(orig.shape[0],math.ceil(y+h)),max(0,int(x)):min(orig.shape[1],math.ceil(x+w))];med=np.median(area) if area.size else 255;color='#FAFFFF' if med<140 else '#122A37'
   chars=sum(1 if ord(ch)>255 else .53 for ch in string);size=min(t.get('size',h*.82),w/max(1,chars)*1.03)
   sp=sl.shapes.add_textbox(*xybox([max(0,x-1),max(0,y-1),w+3,h+4],z,ox,oy));sp.name=f'文字_{string[:30]}';sp.rotation=t.get('rotation',0)
   tf=sp.text_frame;tf.clear();tf.margin_left=tf.margin_right=tf.margin_top=tf.margin_bottom=0;tf.word_wrap=False;tf.vertical_anchor=MSO_ANCHOR.MIDDLE
   p=tf.paragraphs[0];p.alignment=PP_ALIGN.CENTER;p.space_after=Pt(0);p.space_before=Pt(0)
   run=p.add_run();run.text=string;run.font.name='Microsoft YaHei';run.font.size=Pt(size*z*.75);run.font.bold=t.get('bold',h>=22);run.font.color.rgb=rgb(color)
   # Explicit East Asian typeface, portable fallback in PowerPoint and WPS.
   ea=OxmlElement('a:ea');ea.set('typeface','Microsoft YaHei');run._r.get_or_add_rPr().append(ea);count+=1
  sl.notes_slide.notes_text_frame.text='源图：'+c['image']+'。文字、版式结构与关系线为原生对象；设备内部纹理与内置管线保留为裁取图件。\n'+'\n'.join(c.get('review_notes',[]))
  reports.append({'page':idx,'native_textboxes':count,'native_shapes':len(c['shapes']),'equipment_images':len(assets),'review_notes':c.get('review_notes',[])})
 target=ROOT/output;target.parent.mkdir(exist_ok=True,parents=True);prs.save(target);(ROOT/'output/pages_report.json').write_text(json.dumps(reports,ensure_ascii=False,indent=2));return target,reports

def append_deck(baseline,added,target):
 with zipfile.ZipFile(baseline) as z:a={n:z.read(n) for n in z.namelist()}
 with zipfile.ZipFile(added) as z:b={n:z.read(n) for n in z.namelist()}
 prefix='ppt/batch2026/'
 for n,v in b.items():
  if n.startswith('ppt/'):
   if n.endswith('.rels'):
    tree=ET.fromstring(v)
    for rel in tree:
     t=rel.get('Target','')
     if t.startswith('/ppt/'):rel.set('Target','/'+prefix+t[5:])
    v=ET.tostring(tree,xml_declaration=True,encoding='UTF-8',standalone=True)
   a[prefix+n[4:]]=v
 presentation=ET.fromstring(a['ppt/presentation.xml']);lst=presentation.find('{'+NSP+'}sldIdLst');count=len(lst);maxid=max(int(x.get('id')) for x in lst)
 relationships=ET.fromstring(a['ppt/_rels/presentation.xml.rels']);ct=ET.fromstring(a['[Content_Types].xml']);exts={x.get('Extension') for x in ct}
 added_p=ET.fromstring(b['ppt/presentation.xml']);added_list=added_p.find('{'+NSP+'}sldIdLst');slide_rels={r.get('Id'):r.get('Target') for r in ET.fromstring(b['ppt/_rels/presentation.xml.rels'])}
 for j,item in enumerate(added_list,1):
  source=posixpath.normpath(posixpath.join('ppt',slide_rels[item.get('{'+NSD+'}id')]))
  destination=f'ppt/slides/slide{count+j}.xml';a[destination]=b[source]
  relpath=posixpath.join(posixpath.dirname(source),'_rels',posixpath.basename(source)+'.rels');rels=ET.fromstring(b[relpath])
  for r in rels:
   if r.get('TargetMode')=='External':continue
   t=r.get('Target');resolved=t.lstrip('/') if t.startswith('/') else posixpath.normpath(posixpath.join(posixpath.dirname(source),t));r.set('Target',posixpath.relpath(prefix+resolved[4:],'ppt/slides'))
  a[f'ppt/slides/_rels/slide{count+j}.xml.rels']=ET.tostring(rels,xml_declaration=True,encoding='UTF-8',standalone=True)
  rid=f'rIdBatch{j}';ET.SubElement(relationships,'{'+NSR+'}Relationship',Id=rid,Type=NSD+'/slide',Target=f'slides/slide{count+j}.xml');ET.SubElement(lst,'{'+NSP+'}sldId',{'id':str(maxid+j),'{'+NSD+'}id':rid});ET.SubElement(ct,'{'+NSC+'}Override',PartName='/'+destination,ContentType='application/vnd.openxmlformats-officedocument.presentationml.slide+xml')
 for x in ET.fromstring(b['[Content_Types].xml']):
  if x.tag.endswith('Default') and x.get('Extension') not in exts:ct.append(x);exts.add(x.get('Extension'))
  elif x.tag.endswith('Override') and x.get('PartName','').startswith('/ppt/'):
   x.set('PartName','/'+prefix+x.get('PartName')[5:]);ct.append(x)
 for n,e in [('ppt/presentation.xml',presentation),('ppt/_rels/presentation.xml.rels',relationships),('[Content_Types].xml',ct)]:a[n]=ET.tostring(e,xml_declaration=True,encoding='UTF-8',standalone=True)
 with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
  for n,v in a.items():z.writestr(n,v)
 return target

if __name__=='__main__':
 parser=argparse.ArgumentParser(description='Local editable PPTX reconstruction from reviewed image configs.')
 parser.add_argument('--single',type=Path,help='One config JSON; default: all config/page_*.json')
 parser.add_argument('--base',type=Path,help='Optional existing PPTX to append to; original is never overwritten')
 args=parser.parse_args();draft,reports=build([args.single] if args.single else None)
 if args.base:
  target=ROOT/'output/combined.pptx';append_deck(args.base,draft,target);print(target)
 else:print(draft)
 print(json.dumps(reports,ensure_ascii=False,indent=2))
