import AppKit
import Vision
import Foundation
for input in CommandLine.arguments.dropFirst() {
 let url=URL(fileURLWithPath:input)
 guard let image=NSImage(contentsOf:url), let cg=image.cgImage(forProposedRect:nil,context:nil,hints:nil) else {continue}
 let req=VNRecognizeTextRequest(); req.recognitionLevel = .accurate; req.recognitionLanguages=["zh-Hans","en-US"]; req.usesLanguageCorrection=true
 do {try VNImageRequestHandler(cgImage:cg,options:[:]).perform([req])
 let result=(req.results ?? []).compactMap { o -> [String:Any]? in
 guard let t=o.topCandidates(1).first else{return nil}; let b=o.boundingBox
 return ["text":t.string,"confidence":t.confidence,"box":[b.minX*Double(cg.width),(1-b.maxY)*Double(cg.height),b.width*Double(cg.width),b.height*Double(cg.height)]] }
 let data=try JSONSerialization.data(withJSONObject:result,options:[.prettyPrinted,.sortedKeys]);try data.write(to:url.deletingPathExtension().appendingPathExtension("ocr.json")); print("OCR \(url.lastPathComponent): \(result.count) lines")
 }catch{print(error)}
}
