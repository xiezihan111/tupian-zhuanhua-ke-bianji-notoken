# 图片转可编辑 PPT · 本地代码 + Jupyter

把设备插图保留为独立图件，将文字、框架、关系箭头与连接线重建为 PowerPoint 原生对象。保持原图坐标和比例，不调用大模型，不需要 API Key，不上传图片。

这是半自动重建工具，不是任意图片一键无损矢量化。新图仍需标注设备范围、校对文字和检查结果。设备内部纹理与管道轮廓仍为位图；输出清晰度受原图限制。

## 开始使用

需要 Python 3.11 或更高版本。Windows、macOS、Linux 均使用同一 Python 导出程序。

1. 下载 ZIP 并解压。
2. 在文件夹中打开终端，创建独立环境并安装依赖：

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS / Linux:
source .venv/bin/activate
pip install -r requirements.txt
```

3. 运行演示：`python convert.py`，用 PowerPoint 或 WPS 打开 `output/editable.pptx`。
4. 或运行 `jupyter lab start.ipynb`，按顺序执行 Notebook。

## 处理自己的图片

1. 图片放入 `inputs/`。
2. 双击 `annotator.html`。选择原图，选择“设备图件 / 可编辑文字 / 框架 / 箭头 / 连接线”，在原图上拖动标注。文字先在侧栏输入。
3. 下载 `page_01.json` 保存到 `config/`。处理多张时依次命名 `page_02.json` 等。删除不需要的演示配置。
4. 运行 `python convert.py` 或 Notebook。检查生成的 PPT；按需修改 JSON 后重跑。

框架和连线先绘制，图件随后叠放，文字最后写入。裁图区域尽量避开外部箭头；区域内残留的箭头仍是位图。复杂设备轮廓可在 JSON 的 image 对象中加入 `polygon: [[x,y], ...]`，坐标均为原图像素坐标。

## 可选：本地文字识别

macOS 安装 Xcode Command Line Tools 后可运行：

```bash
swift ocr_macos.swift inputs/your-image.png
```

得到 `your-image.ocr.json`，包含识别文字、坐标和置信度，可用于配置 `texts`。Apple Vision 不适用于 Windows；Windows 用户可手工标注或自行接入本地 OCR。OCR 结果必须人工校对，特别是中文小字、旋转文字和设备截图。

## 追加到已有 PPT

```bash
python convert.py --base existing.pptx
```

另存为 `output/combined.pptx`。已有 PPT 不会被覆盖。默认画布是 1239 × 676 像素，向其他尺寸 PPT 追加时请先将 `convert.py` 的 WIDTH、HEIGHT 改为相应比例。

## 使用成本与限制

- 配置和导出运行本地代码，不产生大模型 token 或 API 调用费用。
- 初次下载 Python 依赖需要网络和磁盘空间；代码包本身很小，不包含环境和模型权重。
- 新图的标注与校对仍需要时间；如果再请 AI 协助识别或标注，该部分仍会消耗 token。
- 已在 macOS Python 3.13 中验证演示和批量导出；Windows/Linux 未实机测试。
- 中文字体默认 Microsoft YaHei。系统缺少该字体时，办公软件可能替换字体，需检查换行和宽度。
- 示例图片由代码绘制，仓库不包含教材图片或用户文件。

文件：`convert.py` 导出器；`annotator.html` 本地标注工具；`start.ipynb` Notebook；`config/` 坐标配置；`inputs/demo.png` 原创示例。
